var quests = [
    {//0
        title: "Дом",
        description: "Обычное утро. Тебе снится сон, и вот... Звонит будильник.",
        image: "img/1.1.jpeg",
        asks: [
            {
                question: "Поспишь ещё или на пары пойдёшь?(посплю, пойду)",
                answers: [
                    {
                        text: "пойду",
                        goTo: 2,
                    }, {
                        text: "посплю",
                        goTo: 1,
                    }
                ],
                goToWrong: 0,
            }
        ]
    }, {//1
        title: "Дом",
        description: "Ты выключил будильник и спишь... А он снова звенит!",
        image: "img/obhaga.jpg",
        asks: [
            {
                question: "Поспишь ещё?",
                answers: [
                    {
                        text: "да",
                        goTo: 3,
                    }, {
                        text: "нет",
                        goTo: 5,
                    }
                ],
                goToWrong: 5,
            }
        ]
    }, {//2
        title: "Общага",
        description: "Ты встал. Каким-то образом после первого же будильника.",
        image: "img/obhaga.jpg",
        asks: [
            {
                question: "Ну тогда погнали на пары?",
                answers: [
                    {
                        text: "да",
                        goTo: 8,
                    }, {
                        text: "нет",
                        goTo: 3,
                    }
                ],
                goToWrong: 6,
            }
        ]
    }, {//3
        title: "Общага",
        description: "Ты снова спишь, а будильник снова звенит...",
        image: "img/obhaga.jpg",
        asks: [
            {
                question: "Может ну его, поспишь ещё?",
                answers: [
                    {
                        text: "да",
                        goTo: 4,
                    }, {
                        text: "нет",
                        goTo: 5,
                    }
                ],
                goToWrong: 4,
            }
        ]
    }, {//4
        title: "Конец игры!",
        description: "Как же всё таки хорошо лежать утром в кроватке... Только вот ты проспал. И опоздал на пары.",
        image: "img/gameover.jpg",
        asks: [
            {
                exit: true,
            }
        ]
    }, {//5
        title: "Общага",
        description: "Ты встал... Дурацкое утро... Чтож, надо одеваться и готовиться идти на пары.",
        image: "img/obhaga.jpg",
        asks: [
            {
                question: "Идешь кушать?",
                answers: [
                    {
                        text: "да",
                        goTo: 8,
                    },{
                        text: "нет",
                        goTo: 14,
                    }
                ],
                
                goToWrong: 6,
            }
        ]
    }, {//6
        title: "Улица",
        description: "Ты пожадничал,устал и не дошёл.",
        image: "img/street.jpg",
        asks: [
            {
                exit: true,
            }
        ]
    }, {//7
        title: "Конец игры!",
        description: "Ничего так ничего. Ты проголодался по пути в универ. И не дошёл.",
        image: "img/gameover.jpg",
        asks: [
            {
                exit: true,
            }
        ]
    }, {//8
        title: "Общага",
        description: "Кушать охота....Из съедобного ты нашёл только фрукты и бутер... И воду.",
        image: "img/obhaga.jpg",
        asks: [
            {
                question: "Что из этого берём? (фрукты, воду, бутер, всё)",
                answers: [
                    {
                        text: "фрукты",
                        goTo: 10,
                    }, {
                        text: "воду",
                        goTo: 11,
                    }, {
                        text: "бутер",
                        goTo: 12,
                    }, {
                        text: "всё",
                        goTo: 6,
                    }
                ],
                goToWrong: 9,
            }
        ]
    }, {//9
        title: "Общага",
        description: "Четвёртого не дано. Работу найди, тогда нормальную еду себе выбирать и будешь.",
        image: "img/obhaga.jpg",
        asks: [
            {
                question: "выбирай ещё раз",
                answers: [
                    {
                        text: "да",
                        goTo: 8,
                    }
                ],
                continue: true,
                goToWrong: 8,
            }
        ]
    }, {//10
        title: "Улица",
        description: "Судя по всему, ты за ЗОЖ. Поэтому, выйдя из общаги, ты пешком направился к универу.",
        image: "img/street.jpg",
        asks: [
            {
                question: "Педем на автобусе?",
                answers: [
                    {
                        text: "да",
                        goTo: 13,
                    },{
                        text: "нет ",
                        goTo: 14,
                    }
                ],
                goToWrong: 14,
            }
        ]
    }, {//11
        title: "Общага",
        description: "Только воду, серьёзно?.. Ну ладно, как хочешь. С голоду только не помри, а то на пары всё равно идти придётся.",
        image: "img/obhaga.jpg",
        asks: [
            {
                question: "Выходим на улицу?",
                answers: [
                    {
                        text: "да",
                        goTo: 12,
                    },{
                        text: "нет",
                        goTo: 14,
                    }
                ],
                goToWrong: 14,
            }
        ]
    }, {//12
        title: "Улица",
        description: "Ты взял, что хотел, вышел на улицу, и вдруг увидел, что твой автобус уже на остановке.",
        image: "img/street.jpg",
        asks: [
            {
                question: "Побежишь, чтобы успеть?",
                answers: [
                    {
                        text: "да",
                        goTo: 13,
                    }, {
                        text: "нет",
                        goTo: 14,
                    }
                ],
                goToWrong: 14,
            }
        ]
    }, {//13
        title: "Автобус",
        description: "Вот удача - не только на автобус успел, но и место в нём свободное нашел.",
        image: "img/bus.jpg",
        asks: [
            {
                question: "Сядешь?",
                answers: [
                    {
                        text: "да",
                        goTo: 14,
                    }, {
                        text: "нет",
                        goTo: 15,
                    }
                ],
                goToWrong: 15,
            }
        ]
    }, {//14
        title: "Конец игры!",
        description: "Это был неверный выбор...",
        image: "img/gameover.jpg",
        asks: [
            {
                exit: true,
            }
        ]
    }, {//15
        title: "Универ",
        description: "Избежав гнева злобных бабушек, ты спокойно доехал до нужной остановки.Ты в универе, красавчик",
        image: "img/udgu.jpg",
        asks: [
            {
                exit: true,
            }
        ]
    },
]
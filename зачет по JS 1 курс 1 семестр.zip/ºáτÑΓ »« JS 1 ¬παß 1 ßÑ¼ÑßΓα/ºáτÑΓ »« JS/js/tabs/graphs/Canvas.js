class Canvas {
    constructor({ id, width = 500, height = 500, WIN, callbacks }) {
        this.WIN = WIN;
        this.canvas = document.getElementById(id);
        this.context = this.canvas.getContext('2d');
        this.canvas.width = width;
        this.canvas.height = height;
        //канвас в декартовую
        this.xs = (x) => (x - WIN.left) / WIN.width * this.canvas.width;
        this.ys = (y) => (y - WIN.bottom) / WIN.height * this.canvas.height;

        const { wheel, mouseUp, mouseDown, mouseMove, mouseLeave } = callbacks;
        this.canvas.addEventListener('wheel', wheel);
        this.canvas.addEventListener('mousedown', mouseDown);
        this.canvas.addEventListener('mousemove', mouseMove);
        this.canvas.addEventListener('mouseup', mouseUp);
        this.canvas.addEventListener('mouseleave', mouseLeave);
    }
    clear(color) {
        this.context.fillStyle = color || '#fff';
        this.context.fillRect(0, 0, this.canvas.width, this.canvas.height);
    };

    //декартовая в канвас
    sx = (x) => x * this.WIN.width / this.canvas.width;
    sy = (y) => y * this.WIN.height / this.canvas.height;

    line(x1, y1, x2, y2, color, width, isDash) {
        this.context.beginPath();
        this.context.strokeStyle = color || '#000';
        this.context.lineWidth = width || 1;
        if (isDash) {
            this.context.setLineDash([15, 30]);
        } else {
            this.context.setLineDash([]);
        }
        this.context.moveTo(this.xs(x1), this.ys(y1));
        this.context.lineTo(this.xs(x2), this.ys(-y2));
        this.context.stroke();
    };

    point(x, y, color = 'red', size = 3) {
        this.context.beginPath();
        this.context.strokeStyle = color;
        this.context.arc(this.xs(x), this.ys(y), size, 0, 2 * Math.PI);
        this.context.stroke;
        this.context.fillStyle = color;
        this.context.fill();
    }

    rect(x1, y1, x2, y2, color = '#6666ff') {
        this.context.beginPath();
        this.context.moveTo(this.xs(x1), this.ys(y1));
        this.context.lineTo(this.xs(x1), this.ys(y2));
        this.context.lineTo(this.xs(x2), this.ys(y2));
        this.context.lineTo(this.xs(x2), this.ys(y1));
        this.context.lineTo(this.xs(x1), this.ys(y1));
        this.context.fillStyle = color;
        this.context.fill();
    }

    polygon(points = [], color = '#0f05') {
        if (points.length >= 3) {
            this.context.beginPath();
            this.context.strokeStyle = color;
            this.context.fillStyle = color;
            this.context.moveTo(this.xs(points[0].x), this.ys(points[0].y));
            for (let i = 1; i < points.length; i++) {
                this.context.lineTo(this.xs(points[i].x), this.ys(points[i].y));
            }
            this.context.lineTo(this.xs(points[0].x), this.ys(points[0].y));
            //this.context.closePath();
            //this.context.stroke();
            this.context.fill();
        }
    }

    text(text, x, y) {
        this.context.fillStyle = '#003366';
        this.context.font = 'bold 15px Comic Sans MC';
        this.context.textAlign = 'left';
        this.context.fillText(text, this.xs(x), this.ys(y));
    }

    cursorX = (x) => x * this.WIN.width / this.canvas.width + this.WIN.left;
    cursorY = (y) => y * this.WIN.height / this.canvas.height + this.WIN.bottom;

    cursorCell(x, y, color) {
        this.context.beginPath();
        this.context.moveTo(this.xs(x), this.ys(y));
        this.context.lineTo(this.xs(x + 1), this.ys(y));
        this.context.lineTo(this.xs(x + 1), this.ys(y + 1));
        this.context.lineTo(this.xs(x), this.ys(y + 1));
        this.context.fillStyle = color || green;
        this.context.fill();
    }

    cursorCoord(x, y) {
        this.context.fillStyle = '#003366';
        this.context.font = 'bold 15px Comic Sans MC';
        this.context.textAlign = 'left';
        this.context.fillText('(' + (x + 1) + ',' + -y + ')', this.xs(x + 1), this.ys(y));
        this.context.fillText('(' + (x + 1) + ',' + -(y + 1) + ')', this.xs(x + 1), this.ys(y + 1));
        this.context.textAlign = 'right';
        this.context.fillText('(' + x + ',' + -y + ')', this.xs(x), this.ys(y));
        this.context.fillText('(' + x + ',' + -(y + 1) + ')', this.xs(x), this.ys(y + 1));
    }
}
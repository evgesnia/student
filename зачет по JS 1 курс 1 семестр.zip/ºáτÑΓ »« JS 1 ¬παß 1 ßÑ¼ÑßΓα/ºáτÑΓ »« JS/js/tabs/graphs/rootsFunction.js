function equat1(a, b) { // первая степень
    if (a == 0) {
        if (b == 0) return [];
        return null;
    }
    return [-b / a];
}

function equat2(a, b, c) { // вторая степень
    if (a == 0) return (equat1(b, c));
    var d = b * b - 4 * a * c;
    if (d > 0) {
        var x1 = (-b + Math.sqrt(d)) / 2 / a, x2 = (-b - Math.sqrt(d)) / 2 / a;
        return [x1, x2];
    }
    if (d == 0) {
        return [-b / 2 / a];
    }
    return null;
}

function equat3(a, b, c, d) { //третья степень
    if (a == 0) return (equat2(b, c, d));
    var p, q, Q, alf, bet, x1, x2, x3, x;
    p = c / a - b * b / 3 / a / a;
    q = d / a - b * c / 3 / a / a + 2 * b * b * b / 27 / a / a / a;
    Q = p * p * p / 27 + q * q / 4;
    alf = Math.cbrt(-q / 2 + Math.sqrt(Q));
    bet = Math.cbrt(-q / 2 - Math.sqrt(Q));
    x1 = alf + bet - b / 3 / a;
    x2 = -x1 / 2 + Math.sqrt(-3) * (alf - bet) / 2 - b / 3 / a;
    x3 = -x1 / 2 - Math.sqrt(-3) * (alf - bet) / 2 - b / 3 / a;
    x = [x1, x2, x3];
    return (x);
}

function equat4(a, b, c, d, e) {//четвертая степень
    var q = a;
    a = b / q;
    b = c / q;
    c = d / q;
    d = e / q;
    var y = equat3(1, -b, a * c - 4 * d, -a * a * d + 4 * b * d - c * c);
    var y1 = y[0];
    var xright = equat2(a * a / 4 - b + y1, a * y1 / 2 - c, y1 * y1 / 4 - d);
    var xsolve = xright[0];
    var x1 = equat2(1, a / 2 - Math.sqrt(a * a / 4 - b + y1), y1 / 2 + xsolve * Math.sqrt(a * a / 4 - b + y1));
    var x2 = equat2(1, a / 2 + Math.sqrt(a * a / 4 - b + y1), y1 / 2 + xsolve * Math.sqrt(a * a / 4 - b + y1));

    var answerx = [x1[0], x1[1], x2[0], x2[1]];
    return (answerx);
}

function getRoots(a, b, c, d, e) {
    const WIN = {
        left: -10,
        bottom: -10,
        width: 20,
        height: 20
    };
    const canvas1 = new Canvas({
        id: 'graph1',
        width: 300,
        height: 300,
        WIN,
        callbacks: { wheel, mouseUp, mouseDown, mouseMove, mouseLeave }
    });
    canvas1.clear();

    let f;
    if (a && e) f = (x) => (a * x * x * x * x + b * x * x * x + c * x * x + d * x + e);
    else if (a && d) f = (x) => (a * x * x * x + b * x * x + c * x + d);
    else if (a && c) f = (x) => (a * x * x + b * x + c);
    else if (a && b) f = (x) => (a * x + b);
    else if (a) f = (x) => a;

    function cursorXY(event) {
        const cx = canvas1.cursorX(event.clientX - 8);
        const cy = canvas1.cursorY(event.clientY - 556);

        const xb = cx > 0 ? Math.trunc(cx) : Math.trunc(cx) - 1;
        const yb = cy > 0 ? Math.trunc(cy) : Math.trunc(cy) - 1;
        canvas1.cursorCell(xb, yb, '#3399ff');
        canvas1.cursorCoord(xb, yb);
    }

    const zoom = 0.8;
    function wheel(event) {
        const delta = event.wheelDelta > 0 ? -zoom : zoom;
        if (WIN.width > zoom || delta > 0) {
            WIN.width += delta;
            WIN.height += delta;
            WIN.left -= delta / 2;
            WIN.bottom -= delta / 2;

            render(f);
            cursorXY(event);
        }
    }

    let canMove = false;

    function mouseDown() {
        canMove = true;
    }
    function mouseUp() {
        canMove = false;
    }
    function mouseLeave() {
        render(f);
        canMove = false;
    }
    function mouseMove(event) {
        if (canMove) {
            const { movementX, movementY } = event;
            WIN.left -= canvas1.sx(movementX);
            WIN.bottom -= canvas1.sx(movementY);
            render(f);
        }
        if (!canMove) {
            render(f);
            cursorXY(event);
        }
    }

    function render(f) {
        canvas1.clear('#C7CFFF');
        const { left, bottom, height, width } = WIN;

        for (var x = 0; x < left + width; x += 1) {
            canvas1.line(x, bottom, x, bottom + height, 'white');
        }
        for (var x = 0; x > left; x -= 1) {
            canvas1.line(x, bottom, x, bottom + height, 'white');
        }
        for (var y = 0; y < bottom + height; y += 1) {
            canvas1.line(left, y, left + width, y, 'white');
        }
        for (var y = 0; y > bottom; y -= 1) {
            canvas1.line(left, y, left + width, y, 'white');
        }

        canvas1.line(left, 0, width + left, 0, '#1A224B', 2);//оси
        canvas1.line(0, bottom, 0, bottom + height, '#1A224B', 2);

        canvas1.line(0, bottom, 1, WIN.bottom + 1, '#1A224B', 2);//стрелочки
        canvas1.line(0, bottom, -1, bottom + 1, '#1A224B', 2);

        canvas1.line(left + width, 0, left + width - 1, 1, '#1A224B', 2);
        canvas1.line(left + width, 0, left + width - 1, -1, '#1A224B', 2);

        printFunction(f);
    }

    function printFunction(f) {

        const dx = WIN.width / 100;
        let x = WIN.left;

        while (x < WIN.width + WIN.left) {
            canvas1.line(x, -f(x), x + dx, -f(x + dx), 'blue');
            x += dx;
        }
    }

    render(f);

    if (!isNaN(a) && !isNaN(b) && !isNaN(c) && !isNaN(d) && !isNaN(e))
        return equat4(a, b, c, d, e);
    if (!isNaN(a) && !isNaN(b) && !isNaN(c) && !isNaN(d))
        return equat3(a, b, c, d);
    if (!isNaN(a) && !isNaN(b) && !isNaN(c))
        return equat2(a, b, c);
    if (!isNaN(a) && !isNaN(b))
        return equat1(a, b);
    return null;
}
function oneShot(x, y) { //куда попал, возвращает колво очков
    var canvas = document.getElementById("aim1");
    var drawing = canvas.getContext("2d");

    y=-y;

    drawing.beginPath(); //звезда
    drawing.moveTo(160 + x * 150, 150 + y * 150);
    drawing.quadraticCurveTo(150 + x * 150, 150 + y * 150, 150 + x * 150, 160 + y * 150);
    drawing.quadraticCurveTo(150 + x * 150, 150 + y * 150, 140 + x * 150, 150 + y * 150);
    drawing.quadraticCurveTo(150 + x * 150, 150 + y * 150, 150 + x * 150, 140 + y * 150);
    drawing.quadraticCurveTo(150 + x * 150, 150 + y * 150, 160 + x * 150, 150 + y * 150);
    drawing.fillStyle = "rgb(255, 255, 0)";
    drawing.fill();

    drawing.beginPath(); //пуля попала
    drawing.arc(150 + x * 150, 150 + y * 150, 2, 0, Math.PI * 2, true);
    drawing.fillStyle = "rgb(255, 0, 0)";
    drawing.fill();

    return shotCenter(x, y) || shotStar(x, y) || shotRhomb(x, y) ||
        shotCircle(x, y) || shotSquare(x, y) || 0;
}
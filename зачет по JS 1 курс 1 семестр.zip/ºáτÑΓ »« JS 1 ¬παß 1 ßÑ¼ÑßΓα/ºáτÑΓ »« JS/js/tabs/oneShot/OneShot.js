function OneShot() {
    this.button = function () {
        var canvas = document.getElementById("aim1");
        var drawing = canvas.getContext("2d");

        drawing.fillStyle = "rgb(30,89,69)";
        drawing.fillRect(0, 0, 300, 300);

        drawing.beginPath(); //круг
        drawing.arc(150, 150, 150, 0, Math.PI * 2, true);
        drawing.fillStyle = "rgb(68,148,74)";
        drawing.fill();

        drawing.beginPath(); //ромб
        drawing.moveTo(150, 0);
        drawing.lineTo(300, 150);
        drawing.lineTo(150, 300);
        drawing.lineTo(0, 150);
        drawing.lineTo(150, 0);
        drawing.fillStyle = "rgb(168,228,160)";
        drawing.fill();

        drawing.beginPath(); //звезда
        drawing.moveTo(150, 0);
        drawing.quadraticCurveTo(170, 120, 300, 150);
        drawing.quadraticCurveTo(170, 170, 150, 300);
        drawing.quadraticCurveTo(120, 170, 0, 150);
        drawing.quadraticCurveTo(120, 120, 150, 0);
        drawing.fillStyle = "rgb(189,236,182)";
        drawing.fill();

        drawing.beginPath(); //центр
        
        drawing.arc(150, 150, 1, 0, Math.PI * 2, true);
        drawing.stroke();

        var x = document.getElementById('x1').value - 0;
        var y = document.getElementById('y1').value - 0;
        document.getElementById('result1').innerHTML = 'Твой результат ' + oneShot(x, y) + "!";
    }
}
function shotCoor(min, max) { //случайные коры выстрела
    return Math.random() * (max - min) + min;
}

function shotCenter(x, y) { //попал в центр
    return (x == 0 && y == 0) ? 10 : 0;
}

function shotStar(x, y) { //попал в звезду
    return (Math.cbrt(x * x) + Math.cbrt(y * y) <= 1) ? 4 : 0;
}

function shotRhomb(x, y) { //попал в ромб
    return ((y >= 0 && y <= -Math.abs(x) + 1) || (y <= 0 && y >= Math.abs(x) - 1)) ? 3 : 0;
}

function shotCircle(x, y) { //попал в круг
    return (x * x + y * y <= 1) ? 2 : 0;
}

function shotSquare(x, y) { //попал в квадрат
    return (Math.abs(x) <= 1 && Math.abs(y) <= 1) ? 1 : 0;
}

function shot(min, max) { //куда попал, возвращает колво очков
    var x = shotCoor(min, max);
    var y = shotCoor(min, max);
    y=-y;

    var canvas = document.getElementById("aim");
    var drawing = canvas.getContext("2d");

    drawing.beginPath(); //звезда
    drawing.moveTo(160 + x * 150, 150 + y * 150);
    drawing.quadraticCurveTo(150 + x * 150, 150 + y * 150, 150 + x * 150, 160 + y * 150);
    drawing.quadraticCurveTo(150 + x * 150, 150 + y * 150, 140 + x * 150, 150 + y * 150);
    drawing.quadraticCurveTo(150 + x * 150, 150 + y * 150, 150 + x * 150, 140 + y * 150);
    drawing.quadraticCurveTo(150 + x * 150, 150 + y * 150, 160 + x * 150, 150 + y * 150);
    drawing.fillStyle = "rgb(255, 255, 0)";
    drawing.fill();

    drawing.beginPath(); //пуля попала
    drawing.arc(150 + x * 150, 150 + y * 150, 2, 0, Math.PI * 2, true);
    drawing.fillStyle = "rgb(255, 0, 0)";
    drawing.fill();

    return shotCenter(x, y) || shotStar(x, y) || shotRhomb(x, y) ||
        shotCircle(x, y) || shotSquare(x, y) || 0;
}

function shooter(count, min, max) { //стреляет count раз от min до max
    var result = 0;

    for (var i = 0; i < count; ++i) {
        result = result + shot(min, max);
    }
    return result;
}

function winningPhrase(score, count){
    phrase = score/count;
    if(phrase<1) return "Тебе даже сказали где мишень...";
    if(phrase<2) return "Мда... Попробуй всё-таки в мишень целиться";
    if(phrase<3) return "Неплохо";
    if(phrase<4) return "Да ты меткий!";
    return "O-O круто";
}
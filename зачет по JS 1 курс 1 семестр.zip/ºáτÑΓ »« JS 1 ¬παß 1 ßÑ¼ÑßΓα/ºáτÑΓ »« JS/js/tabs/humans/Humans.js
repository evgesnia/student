function Humans() {
    this.create = function () {
        var name = document.getElementById('humanName').value;
        var age = document.getElementById('humanAge').value - 0;
        var money = document.getElementById('humanMoney').value - 0;
        var gender = document.getElementById('humanGender').value;
        if (name) {
            if (age == 0) {
                money = 0;
            }
            var check = 0;
            for (var i = 0; i < humans.length; i++) {
                if (humans[i].name == name) {
                    check = 1;
                }
            }
            if (check == 0) {
                if (gender.toLowerCase() == 'м') {
                    var newHuman = new Human(name, age, money);
                }
                if (gender.toLowerCase() == 'ж') {
                    var newHuman = new Woman(name, age, money);
                }
                if (gender.toLowerCase() == 'м' || gender.toLowerCase() == 'ж') {
                    humans.push(newHuman);
                    var people = document.createElement('div');

                    var humanName = document.createElement('span');
                    var humanAge = document.createElement('span');
                    var humanGender = document.createElement('span');

                    humanName.innerHTML = newHuman.name + " ";
                    humanAge.innerHTML = newHuman.age + " ";
                    humanGender.innerHTML = newHuman.gender + " ";

                    people.appendChild(humanName);
                    people.appendChild(humanAge);
                    people.appendChild(humanGender);

                    document.getElementById('allHumans').appendChild(people);
                }
            }
            document.getElementById('humanName').value = "";
            document.getElementById('humanAge').value = "";
            document.getElementById('humanMoney').value = "";
            document.getElementById('humanGender').value = "";
        }
    }

    this.revive = function () {
        var necromancer = document.getElementById('necromancer').value;
        var zombie = document.getElementById('zombie').value;
        if (necromancer && zombie) {
            var adult = 0;
            for (var i = 0; i < humans.length; i++) {
                if (humans[i].name == necromancer) {
                    if (humans[i].age >= 18) {
                        adult = 1;
                        humans[i].stamina = humans[i].stamina / 2;
                        humans[i].money = 0;
                    }

                }
            }
            for (var i = 0; i < humans.length; i++) {
                if (humans[i].name == zombie && adult == 1) {
                    humans[i].status = "alive";
                    humans[i].stamina = 100;
                    humans[i].money = 0;
                }
            }
        }
    }

    this.work = function () {
        worker = document.getElementById('work').value;
        worktime = document.getElementById('workTime').value - 0;
        for (var i = 0; i < humans.length; i++) {
            if (humans[i].name == worker) {
                if (humans[i].status == "alive") {
                    humans[i].work(worktime);
                }
            }
        }
    }

    this.eat = function () {
        worker = document.getElementById('eat').value;
        for (var i = 0; i < humans.length; i++) {
            if (humans[i].name == worker) {
                if (humans[i].status == "alive") {
                    humans[i].eat();
                }
            }
        }
    }

    this.party = function () {
        worker = document.getElementById('party').value;
        for (var i = 0; i < humans.length; i++) {
            if (humans[i].name == worker) {
                if (humans[i].status == "alive") {
                    humans[i].party();
                }
            }
        }
    }

    this.addKid = function () {
        var kidName = document.getElementById('kidName').value;
        if (kidName) {
            var check = 0;
            for (var i = 0; i < humans.length; i++) {
                if (humans[i].name == kidName) {
                    check = 1;
                }
            }
            var genderRandom = Math.random() * 2;
            if (check == 0) {
                if (genderRandom < 1) {
                    var newHuman = new Human(kidName);
                }
                if (genderRandom >= 1) {
                    var newHuman = new Woman(kidName);
                }

                humans.push(newHuman);
                var people = document.createElement('div');

                var humanName = document.createElement('span');
                var humanAge = document.createElement('span');
                var humanGender = document.createElement('span');

                humanName.innerHTML = newHuman.name + " ";
                humanAge.innerHTML = newHuman.age + " ";
                humanGender.innerHTML = newHuman.gender + " ";

                people.appendChild(humanName);
                people.appendChild(humanAge);
                people.appendChild(humanGender);

                document.getElementById('allHumans').appendChild(people);
            }
        }
    }

    this.multiply = function () {
        worker1 = document.getElementById('multiply1').value;
        worker2 = document.getElementById('multiply2').value;

        document.getElementById('kid').innerHTML = "";
        document.getElementById('yeshomo').src = "";

        if (worker1 && worker2) {
            if (worker1 == worker2) {
                for (var i = 0; i < humans.length; i++) {
                    if (humans[i].name == worker1) {
                        humans[i].happy = 100;
                    }
                }
                var span = document.createElement('span');
                span.innerHTML = "... Так не получится...";
                document.getElementById('kid').appendChild(span);
            }
            if (worker1 != worker2) {
                var homo = 0;
                var dead = 0;
                var adult = 1;
                for (var i = 0; i < humans.length; i++) {
                    if (humans[i].name == worker1) {
                        for (var j = 0; j < humans.length; j++) {
                            if (humans[j].name == worker2) {
                                if (humans[i].age < 16 || humans[j].age < 16) {
                                    adult = 0;
                                }

                                if (humans[i].status == "dead" || humans[j].status == "dead") {
                                    dead = 1;
                                }

                                if (humans[i].gender == humans[j].gender) {
                                    homo = 1;
                                }

                                humans[i].happy = 100;
                                humans[j].happy = 100;
                            }
                        }
                    }
                }

                if (dead == 1) {
                    var span = document.createElement('span');
                    span.innerHTML = "Поздравляю, ты некрофил...";
                    document.getElementById('kid').appendChild(span);
                }

                if (dead == 0 && adult == 0) {
                    var span = document.createElement('span');
                    span.innerHTML = "Вaм ещё нельзя, ждите! -_-";
                    document.getElementById('kid').appendChild(span);
                }

                if (dead == 0 && adult == 1) {
                    if (homo == 1) {
                        var div = document.createElement('div');
                        var write = document.createElement('span');
                        write.innerHTML = "..................";
                        div.appendChild(write);
                        document.getElementById('kid').appendChild(div);
                    }
                    if (homo == 0) {
                        var div = document.createElement('div');
                        var success = document.createElement('span');
                        var kidName = document.createElement('input');
                        kidName.id = "kidName";
                        var createKid = document.createElement('button');
                        success.innerHTML = "Поздравляю! Теперь у этих человеков есть свой маленький человек! :3";
                        kidName.placeholder = "введите имя";
                        createKid.addEventListener('click', addKid);
                        createKid.innerHTML = "Назвать";

                        div.appendChild(success);
                        div.appendChild(kidName);
                        div.appendChild(createKid);

                        document.getElementById('kid').appendChild(div);
                    }
                }
            }
        }
    }

    this.check = function () {
        var worker = document.getElementById('checkHuman').value;
        document.getElementById('checkHuman').value = "";
        for (var i = 0; i < humans.length; i++) {
            if (humans[i].name == worker) {
                newHuman = humans[i];
            }
        }

        var people = document.createElement('div');

        var humanName = document.createElement('span');
        var humanAge = document.createElement('span');
        var humanGender = document.createElement('span');
        var humanMoney = document.createElement('span');
        var humanStamina = document.createElement('span');
        var humanStatus = document.createElement('span');
        var humanHappy = document.createElement('span');

        humanName.innerHTML = newHuman.name + " ";
        humanAge.innerHTML = newHuman.age + " ";
        humanGender.innerHTML = newHuman.gender + " ";
        humanMoney.innerHTML = newHuman.money + " ";
        humanStamina.innerHTML = newHuman.stamina + " ";
        humanStatus.innerHTML = newHuman.status + " ";
        humanHappy.innerHTML = newHuman.happy + " ";

        people.appendChild(humanName);
        people.appendChild(humanAge);
        people.appendChild(humanGender);
        people.appendChild(humanMoney);
        people.appendChild(humanStamina);
        people.appendChild(humanStatus);
        people.appendChild(humanHappy);

        document.getElementById('humanInfo').innerHTML = "";
        document.getElementById('humanInfo').appendChild(people);
    }
}
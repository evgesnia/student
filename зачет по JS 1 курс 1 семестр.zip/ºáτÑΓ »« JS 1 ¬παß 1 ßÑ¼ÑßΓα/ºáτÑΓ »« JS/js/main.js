function oneShotHandler() {
    const click = new OneShot();
    click.button();
}

function getRootsHandler() {
    const click = new Roots();
    click.button();
}

function shotHandler() {
    const click = new Shot();
    click.button();
}

var humans = [];

function humanHandler() {
    const click = new Humans();
    click.create();
}

function reviveHandler() {
    const click = new Humans();
    click.revive();
}

function workHandler() {
    const click = new Humans();
    click.work();
}

function eatHandler() {
    const click = new Humans();
    click.eat();
}

function partyHandler() {
    const click = new Humans();
    click.party();
}

function addKid() {
    const click = new Humans();
    click.addKid();
}

function multiplyHandler() {
    const click = new Humans();
    click.multiply();
}

function checkHumanHandler() {
    const click = new Humans();
    click.check();
}

function menuButtonHandler(event) {
    var contents = document.querySelectorAll('.content-item');
    for (var i = 0; i < contents.length; i++) {
        contents[i].classList.add('hide');
    }
    var id = event.target.dataset.content;
    document.getElementById(id).classList.remove('hide');
}

function calculatorsButtonHandler(event) {
    const contents = document.querySelectorAll('.calculatorContent-item');
    for (let i = 0; i < contents.length; i++) {
        contents[i].classList.add('.hide');
    }
    const id = event.target.dataset.content;
    document.getElementById(id).classList.remove('hide');
}

function popUpOpenHandler() {
    let popUp = document.getElementById('popUp');
    popUp.classList.remove('hide');
}

function popUpCloseHandler() {
    let popUp = document.getElementById('popUp');
    popUp.classList.add('hide');
}

window.onload = function () {
    new Graph2D;
    /*new calculatorsMenu;
    new polyCalcMenu;*/
    document.querySelectorAll('.topbar-btn').forEach(e => e.addEventListener('click', topbarHandler));
    calculate();
    poly();
    

    document.getElementById('shot').addEventListener('click', shotHandler);
    document.getElementById('oneShot').addEventListener('click', oneShotHandler);
    document.getElementById('getRoots').addEventListener('click', getRootsHandler);
    document.getElementById('createHuman').addEventListener('click', humanHandler);
    document.getElementById('revive').addEventListener('click', reviveHandler);
    document.getElementById('working').addEventListener('click', workHandler);
    document.getElementById('eating').addEventListener('click', eatHandler);
    document.getElementById('partying').addEventListener('click', partyHandler);
    document.getElementById('multiplying').addEventListener('click', multiplyHandler);
    document.getElementById('checkHumanButton').addEventListener('click', checkHumanHandler);

    document.getElementById('popUpOpen').addEventListener('click', popUpOpenHandler);
    document.getElementById('popUpClose').addEventListener('click', popUpCloseHandler);

    var menuButtons = document.querySelectorAll('.menu-item');
    for (var i = 0; i < menuButtons.length; i++) {
        menuButtons[i].addEventListener('click', menuButtonHandler);
    }

  /*  const calculatorsButtons = document.querySelectorAll('.calculatorMenu-item');
    for (let i = 0; i < calculatorsButtons.length; i++) {
        calculatorsButtons[i].addEventListener('click', calculatorsButtonHandler)
    } */
    
    setQuest();
};

function topbarHandler(event) {
    document.querySelectorAll('.content-item').forEach(e => e.classList.add('hidden'));
    document.getElementById(event.target.dataset.content).classList.remove('hidden');
}
